

angular.module('routes').controller.('routeController', [ '$scope', '$location'
	function($scope, $location) {
		$scope.showMenu = $location.path != '/';
	} ]);

digitalbankingControllers.controller('loginCtrl', [ '$scope', '$http', 'User', 'LoginService', '$location'
	function($scope, $http, User, LoginService, $location) {
		$scope.User = User;

		$scope.login = function() {
			LoginService.Login($scope.User.username, $scope.User.password).success(function(data, status, headers, config) {
				console.log(data);
				$scope.authResult = data.authResult;
				if(authResult == 'success')
				{
					$location.path('/home');
				}
			});
		}
		
		$scope.logout = function() {				
			var url = "php/ReadCookie.php?action=delete";
            $http.get(url).success(function (response) {		
                User.password = "";
                User.isLogged = response[0].loggedin;
                User.username = response[0].username;
                $scope.User = User;
            });            								
			User.isLogged = "false";
			User.username = "";
			User.password = "";
			$scope.User = User;
			$("#adminMenu").hide();
		}
		
	} ]);
	
digitalbankingControllers.controller('HomeController', [ '$scope', function($scope) {
			
}]);
		
digitalbankingControllers.controller('AccountSummaryController', [ '$scope', 'AccountsService', function($scope, AccountsService) {
		$scope.accountsSummary = {};
		
		getAccountsSummary();
		function getAccountsSummary()
		{
			AccountsService.getAccountSummary().success(function(data, status, headers, config) {
				if(data != null)
				{
					$scope.accountsSummary = JSON.parse(data);
				}
			});
		}
}]);