(function(){
	angular.module('routes',['ngRoute'])
	.config([ '$routeProvider', function($routeProvider) {
	$routeProvider.when('/', {
		templateUrl : 'includes/login.html',
		controller : 'LoginController'
	})
	.when('/home', {
		templateUrl : 'includes/home.html',
		controller : 'HomeController'
	})
	.when('/accountSummary',{
		templateUrl : 'includes/accountSummary.html',
		controller : 'AccountSummaryController'
	});

	$routeProvider.otherwise({
		redirectTo : '/'
	});
} ])
})();