digitalbankingServices.factory('AccountsService',['$http','$location','$rootScope', '$q', function($http, $location, $rootScope) {
	var service = {};
	service.getAccountSummary = function(username, password) {
		return $http.get('webapi/security/authenticate');
	};

	return service;
}]);